
import React, { useState } from 'react';
import { ShoppingCart, User, LogIn, UserPlus } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { Button } from '@/components/ui/button';
import LoginModal from './LoginModal';
import SignupModal from './SignupModal';
import CartDrawer from './CartDrawer';

const Header = () => {
  const { user, logout } = useAuth();
  const { itemCount } = useCart();
  const [showLogin, setShowLogin] = useState(false);
  const [showSignup, setShowSignup] = useState(false);
  const [showCart, setShowCart] = useState(false);

  return (
    <>
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold text-slate-900">Luxora</h1>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-gray-700 hover:text-slate-900 transition-colors">Home</a>
              <a href="#" className="text-gray-700 hover:text-slate-900 transition-colors">Products</a>
              <a href="#" className="text-gray-700 hover:text-slate-900 transition-colors">Categories</a>
              <a href="#" className="text-gray-700 hover:text-slate-900 transition-colors">About</a>
            </nav>

            {/* User actions */}
            <div className="flex items-center space-x-4">
              {user ? (
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-gray-700">Welcome, {user.name}</span>
                  <Button variant="ghost" size="sm" onClick={logout}>
                    Logout
                  </Button>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm" onClick={() => setShowLogin(true)}>
                    <LogIn className="w-4 h-4 mr-2" />
                    Login
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setShowSignup(true)}>
                    <UserPlus className="w-4 h-4 mr-2" />
                    Sign Up
                  </Button>
                </div>
              )}
              
              {/* Cart */}
              <Button variant="ghost" size="sm" onClick={() => setShowCart(true)} className="relative">
                <ShoppingCart className="w-5 h-5" />
                {itemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-blue-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <LoginModal open={showLogin} onClose={() => setShowLogin(false)} />
      <SignupModal open={showSignup} onClose={() => setShowSignup(false)} />
      <CartDrawer open={showCart} onClose={() => setShowCart(false)} />
    </>
  );
};

export default Header;

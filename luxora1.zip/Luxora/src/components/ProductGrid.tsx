
import React, { useState } from 'react';
import ProductCard from './ProductCard';
import { Product } from '../contexts/CartContext';
import { Button } from '@/components/ui/button';

const products: Product[] = [
  {
    id: '1',
    name: 'Premium Wireless Headphones',
    price: 24999,
    image: 'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=400',
    category: 'Electronics',
    description: 'High-quality wireless headphones with noise cancellation and premium sound quality.'
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    price: 16699,
    image: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=400',
    category: 'Electronics',
    description: 'Advanced fitness tracking with heart rate monitoring and GPS capabilities.'
  },
  {
    id: '3',
    name: 'Professional Laptop',
    price: 108499,
    image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=400',
    category: 'Electronics',
    description: 'High-performance laptop perfect for work and creativity with latest technology.'
  },
  {
    id: '4',
    name: 'Wireless Mouse',
    price: 6699,
    image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=400',
    category: 'Electronics',
    description: 'Ergonomic wireless mouse with precision tracking and long battery life.'
  },
  {
    id: '5',
    name: 'Mechanical Keyboard',
    price: 12499,
    image: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=400',
    category: 'Electronics',
    description: 'Premium mechanical keyboard with backlit keys and customizable switches.'
  },
  {
    id: '6',
    name: 'Portable Speaker',
    price: 7499,
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400',
    category: 'Electronics',
    description: 'Compact bluetooth speaker with powerful sound and waterproof design.'
  },
  {
    id: '7',
    name: 'Smart Home Hub',
    price: 13299,
    image: 'https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=400',
    category: 'Smart Home',
    description: 'Central control hub for all your smart home devices with voice control.'
  },
  {
    id: '8',
    name: 'Gaming Console',
    price: 41699,
    image: 'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=400',
    category: 'Gaming',
    description: 'Next-generation gaming console with 4K graphics and immersive gameplay.'
  }
];

const categories = ['All', 'Electronics', 'Smart Home', 'Gaming'];

const ProductGrid = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredProducts = selectedCategory === 'All' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Category Filter */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Products</h2>
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              onClick={() => setSelectedCategory(category)}
              className={selectedCategory === category ? 'bg-blue-600 hover:bg-blue-700' : ''}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default ProductGrid;
